(1)ASCII abbreviated from American Standard Code for Information Interchange, is a character encoding standard for electronic communication. ASCII codes represent text in computers

(2)char '0'= 48 ASCII=30 hex
(3)char '1'= 49 ASCII=31 hex
(4)char '9'= 57 ASCII=39 hex

(5)char 'A'= 65 ASCII=41 hex
(6)char 'Z'= 90 ASCII=5A hex

(7)char 'a'= 97  ASCII=61 hex
(8)char 'z'= 122 ASCII=7A hex

char to int conversion
consider a string str:
string str;
cin>>string;
//str be a3635vxgr46
str.at(2) gives a char '6'  =54 in ASCII
(str.at(2)-'0') gives  54-48=6  in ASCII
//(str.at(2)-'0') can be used to convert char to int.
